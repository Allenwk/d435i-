from bin import jkrc
class RC():
    def __init__(self,ip):
       self.jakaRobot = jkrc.RC(ip)
    def login(self,):
        '''连接机器人控制器'''
        return self.jakaRobot.login()
    def logout(self,):
        '''断开控制器连接'''
        return self.jakaRobot.logout()
    def power_on(self,):
        '''打开机器人电源，给真实的机器人上电大概会有 8 秒钟左右的延迟'''
        return self.jakaRobot.power_on()
    def power_off(self,):
        '''关闭机器人电源'''
        return self.jakaRobot.power_off()
    def shut_down(self,):
        '''机器人控制柜关机'''
        return self.jakaRobot.shut_down()
    def enable_robot(self,):
        '''控制机器人上使能'''
        return self.jakaRobot.enable_robot()
    def disable_robot(self,):
        '''控制机器人下使能'''
        return self.jakaRobot.disable_robot()
    def get_sdk_version(self,):
        '''获取 SDK 版本号'''
        return self.jakaRobot.get_sdk_version()
    def get_controller_ip (self,):
        '''获取控制器 IP'''
        return self.jakaRobot.get_controller_ip ()
    def drag_mode_enable(self,enable):
        '''控制器机器人进入或退出拖拽模式'''
        return self.jakaRobot.drag_mode_enable(enable)
    def is_in_drag_mode(self,):
        '''查询机器人是否处于拖拽模式'''
        return self.jakaRobot.is_in_drag_mode()
    def set_debug_mode(self,mode):
        '''设置 SDK 是否开启调试模式。'''
        return self.jakaRobot.set_debug_mode(mode)
    def set_SDK_filepath(self,filepath):
        '''设置 SDK 日志路径'''
        return self.jakaRobot.set_SDK_filepath(filepath)
    def jog(self,aj_num , move_mode, coord_type, jog_vel, pos_cmd):
        '''控制机器人手动模式下运动'''
        return self.jakaRobot.jog(aj_num , move_mode, coord_type, jog_vel, pos_cmd)
    def jog_stop(self,joint_num):
        '''控制机器人手动模式下运动停止，用于停止 jog'''
        return self.jakaRobot.jog_stop(joint_num)
    def get_joint_position(self,):
        '''获取当前机器人的六个关节角度值'''
        return self.jakaRobot.get_joint_position()
    def joint_move(self,joint_pos, move_mode, is_block, speed):
        '''机器人关节运动到目标点位'''
        return self.jakaRobot.joint_move(joint_pos, move_mode, is_block, speed)
    def joint_move_extend(self,joint_pos, move_mode, is_block, speed, acc, tol):
        '''机器人扩展关节运动。增加关节角加速度和关节运动终点误差。'''
        return self.jakaRobot.joint_move_extend(joint_pos, move_mode, is_block, speed, acc, tol)
    def linear_move_extend(self,end_pos, move_mode, is_block, speed, acc, tol):
        '''机器人扩展末端直线运动。增加空间加速度和空间运动终点误差。'''
        return self.jakaRobot.linear_move_extend(end_pos, move_mode, is_block, speed, acc, tol)
    def circular_move_extend (self,end_pos, mid_pos, move_mode, is_block, speed, acc, tol, cricle_cnt):
        '''机器人末端圆弧运动'''
        return self.jakaRobot.circular_move_extend (end_pos, mid_pos, move_mode, is_block, speed, acc, tol, cricle_cnt)
    def set_block_wait_timeout(self,seconds):
        '''机械臂设置阻塞运动超时时间'''
        return self.jakaRobot.set_block_wait_timeout(seconds)
    def motion_abort (self,):
        '''可以在任何情况下终止机器人的运动'''
        return self.jakaRobot.motion_abort ()
    def is_in_pos(self,):
        '''查询机器人运动是否停止'''
        return self.jakaRobot.is_in_pos()
    def get_robot_status (self,):
        '''获取机器人状态数据监测数据,支持多线程安全'''
        return self.jakaRobot.get_robot_status ()
    def set_network_exception_handle (self,millisecond):
        '''设置机器人状态数据自动更新时间间隔，可以改变系统占用率，默认尽可能快地发'''
        return self.jakaRobot.set_network_exception_handle (millisecond)
    def set_digital_output(self,iotype , index , value ):
        '''设置数字输出变量(DO)的值'''
        return self.jakaRobot.set_digital_output(iotype, index, value)
    def set_analog_output(self,iotype , index, value ):
        '''设置模拟输出变量的值(AO)的值'''
        return self.jakaRobot.set_analog_output(iotype, index , value)
    def get_digital_input(self,iotype, index):
        '''查询数字输入(DI)状态'''
        return self.jakaRobot.get_digital_input(iotype, index)
    def get_digital_output(self,iotype, index):
        '''查询数字输出(DO)状态'''
        return self.jakaRobot.get_digital_output(iotype, index)
    def get_analog_input(self,iotype, index):
        '''获取模拟量输入变量(AI)的值'''
        return self.jakaRobot.get_analog_input(iotype, index)
    def get_analog_output(self,type, index):
        '''获取模拟量输出变量(AO)的值'''
        return self.jakaRobot.get_analog_output(type, index)
    def is_extio_running(self,):
        '''查询扩展 IO 模块是否运行'''
        return self.jakaRobot.is_extio_running()
    def set_tool_data(self,id, tcp, name):
        '''设置指定编号的工具信息'''
        return self.jakaRobot.set_tool_data(id, tcp, name)
    def set_tool_id(self,id):
        '''设置当前使用的工具 ID'''
        return self.jakaRobot.set_tool_id(id)
    def get_tool_data(self,id):
        '''查询机器人使用的工具信息'''
        return self.jakaRobot.get_tool_data(id)
    def get_tool_id(self,):
        '''查询机器人当前使用的工具 ID'''
        return self.jakaRobot.get_tool_id()
    def set_user_frame_data(self,id, user_frame, name):
        '''设置用户坐标系信息。'''
        return self.jakaRobot.set_user_frame_data(id, user_frame, name)
    def get_user_frame_data(self,):
        '''获取用户坐标系信息'''
        return self.jakaRobot.get_user_frame_data()
    def get_user_frame_id(self,):
        '''查询当前使用的用户坐标系 ID'''
        return self.jakaRobot.get_user_frame_id()
    def set_user_frame_id(self,id):
        '''设置当前使用的用户坐标系 ID'''
        return self.jakaRobot.set_user_frame_id(id)
    def linear_move(self,end_pos, move_mode, is_block, speed):
        '''机器人末端直线运动到目标点位'''
        return self.jakaRobot.linear_move(end_pos, move_mode, is_block, speed)
    def get_tcp_position(self,):
        '''获取当前设置下工具末端的位姿'''
        return self.jakaRobot.get_tcp_position()
    def get_robot_state(self,):
        '''获取机器人状态'''
        return self.jakaRobot.get_robot_state()
    def set_payload(self,mass, centroid):
        '''机器人负载设置'''
        return self.jakaRobot.set_payload(mass, centroid)
    def get_payload(self,):
        '''获取机器人负载数据'''
        return self.jakaRobot.get_payload()
    def set_tio_vout_param(self,vout_enable ,vout_vol):
        '''4.3.23 设置 tioV3 电压参数'''
        return self.jakaRobot.set_tio_vout_param(vout_enable ,vout_vol)
    def get_tio_vout_param(self,vout_enable ,vout_vol):
        '''获取 tioV3 电压参数'''
        return self.jakaRobot.get_tio_vout_param(vout_enable ,vout_vol)
    def get_robot_state(self,):
        '''获取机械臂状态'''
        return self.jakaRobot.get_robot_state()
    def del_tio_rs_signal(self,sign_name):
        '''添加或修改信号量'''
        return self.jakaRobot.del_tio_rs_signal(sign_name)
    def send_tio_rs_command(self,chn_id, cmd):
        '''RS485 发送指令'''
        return self.jakaRobot.send_tio_rs_command(chn_id, cmd)
    def get_rs485_signal_info(self,):
        '''RS485 信号量信息'''
        return self.jakaRobot.get_rs485_signal_info()
    def set_tio_pin_mode(self,pin_type, pin_mode):
        '''设置 tio 模式'''
        return self.jakaRobot.set_tio_pin_mode(pin_type, pin_mode)
    def get_tio_pin_mode(self,pin_type):
        '''获取 tio 模式'''
        return self.jakaRobot.get_tio_pin_mode(pin_type)
    def is_on_limit(self,):
        '''查询机器人是否超出限位'''
        return self.jakaRobot.is_on_limit()
    def is_in_collision(self,):
        '''查询机器人是否处于碰撞保护模式'''
        return self.jakaRobot.is_in_collision()
    def collision_recover(self,):
        '''碰撞之后从碰撞保护模式恢复'''
        return self.jakaRobot.collision_recover()
    def set_collision_level(self,level):
        '''设置机器人碰撞等级'''
        return self.jakaRobot.set_collision_level(level)
    def get_collision_level(self,):
        '''获取机器人碰撞等级'''
        return self.jakaRobot.get_collision_level()
    def get_last_error (self,):
        '''获取机器人运行过程中最后一个错误码,当调用 clear_error 时，最后一个错误码会清'''
        return self.jakaRobot.get_last_error ()
    def set_errorcode_file_path (self,errcode_file_path):
        '''设置错误码文件路径，使用 get_last_error 接口时，如果要获得具体的错误信息，需要'''
        return self.jakaRobot.set_errorcode_file_path (errcode_file_path)
    def clear_error(self,):
        '''错误状态清除。'''
        return self.jakaRobot.clear_error()
    def set_network_exception_handle (self,millisecond, mnt):
        '''设置网络异常控制句柄，当网络出现异常情况时，控制机器人运动状态。'''
        return self.jakaRobot.set_network_exception_handle (millisecond, mnt)
    def program_load(self,file_name):
        '''加载指定的作业程序'''
        return self.jakaRobot.program_load(file_name)
    def get_loaded_program(self,):
        '''获取已加载的作业程序名称'''
        return self.jakaRobot.get_loaded_program()
    def get_current_line(self,):
        '''获取当前机器人作业程序的执行行号'''
        return self.jakaRobot.get_current_line()
    def program_run(self,):
        '''运行当前加载的作业程序'''
        return self.jakaRobot.program_run()
    def program_pause(self,):
        '''暂停当前运行的作业程序'''
        return self.jakaRobot.program_pause()
    def program_resume(self,):
        '''继续运行当前暂停的作业程序'''
        return self.jakaRobot.program_resume()
    def program_abort(self,):
        '''终止当前执行的作业程序'''
        return self.jakaRobot.program_abort()
    def get_program_state(self,):
        '''获取机器人作业程序执行状态'''
        return self.jakaRobot.get_program_state()
    def set_rapidrate(self,rapid_rate):
        '''设置机器人运行速度倍率'''
        return self.jakaRobot.set_rapidrate(rapid_rate)
    def get_rapidrate(self,):
        '''获取机器人运行速度倍率'''
        return self.jakaRobot.get_rapidrate()
    def set_traj_config(self,xyz_interval, rpy_interval, vel, acc):
        '''设置轨迹复现配置参数, 可设置空间位置采集精度，姿态采集精度，执行脚本运行速'''
        return self.jakaRobot.set_traj_config(xyz_interval, rpy_interval, vel, acc)
    def get_traj_config(self,):
        '''获取轨迹复现配置参数, 可获得空间位置采集精度，姿态采集精度， 执行脚本运行'''
        return self.jakaRobot.get_traj_config()
    def set_traj_sample_mode(self,mode, filename):
        '''采集轨迹复现数据控制开关。'''
        return self.jakaRobot.set_traj_sample_mode(mode, filename)
    def get_traj_sample_status(self,):
        '''采集轨迹复现数据状态查询。注：在数据采集状态时，不允许再次开启数据采集开'''
        return self.jakaRobot.get_traj_sample_status()
    def get_exist_traj_file_name (self,):
        '''查询控制器中已经存在的轨迹复现数据的文件名'''
        return self.jakaRobot.get_exist_traj_file_name ()
    def rename_traj_file_name (self,src, dest):
        '''重命名轨迹复现数据的文件名'''
        return self.jakaRobot.rename_traj_file_name (src, dest)
    def remove_traj_file(self,filename):
        '''删除控制器中轨迹复现数据文件'''
        return self.jakaRobot.remove_traj_file(filename)
    def generate_traj_exe_file(self,filename):
        '''控制器中轨迹复现数据文件生成控制器执行脚本'''
        return self.jakaRobot.generate_traj_exe_file(filename)
    def rpy_to_rot_matrix(self,rpy):
        '''欧拉角到旋转矩阵的转换'''
        return self.jakaRobot.rpy_to_rot_matrix(rpy)
    def rot_matrix_to_rpy(self,rot_matrix):
        '''旋转矩阵到欧拉角的转换'''
        return self.jakaRobot.rot_matrix_to_rpy(rot_matrix)
    def quaternion_to_rot_matrix (self,quaternion):
        '''四元数到旋转矩阵的转换'''
        return self.jakaRobot.quaternion_to_rot_matrix (quaternion)
    def kine_inverse(self,ref_pos, cartesian_pose):
        '''计算指定位姿在当前工具、当前安装角度以及当前用户坐标系设置下的逆解。'''
        return self.jakaRobot.kine_inverse(ref_pos, cartesian_pose)
    def kine_forward(self,joint_pos):
        '''计算指定关节位置在当前工具、当前安装角度以及当前用户坐标系设置下的位姿值'''
        return self.jakaRobot.kine_forward(joint_pos)
    def rot_matrix_to_quaternion(self,rot_matrix):
        '''旋转矩阵到四元数的转换'''
        return self.jakaRobot.rot_matrix_to_quaternion(rot_matrix)
    def servo_move_enable(self,enable):
        '''机器人 SERVO MOVE 模式使能'''
        return self.jakaRobot.servo_move_enable(enable)
    def servo_j(self,joint_pos, move_mode):
        '''机器人关节空间位置控制模式,需要注意的事项如下：'''
        return self.jakaRobot.servo_j(joint_pos, move_mode)
    def servo_j_extend(self,joint_pos, move_mode, setp_num):
        '''(a) 机器人关节空间位置控制模式,需要注意的事项如下：'''
        return self.jakaRobot.servo_j_extend(joint_pos, move_mode, setp_num)
    def servo_p(self,cartesian_pose, move_mode):
        '''机器人笛卡尔空间位置控制模式,需要注意的事项如下：'''
        return self.jakaRobot.servo_p(cartesian_pose, move_mode)
    def servo_p_extend(self,cartesian_pose, move_mode, step_num):
        '''(a) 机器人笛卡尔空间位置控制模式,需要注意的事项如下：'''
        return self.jakaRobot.servo_p_extend(cartesian_pose, move_mode, step_num)
    def servo_move_use_none_filter(self,):
        '''机器人 SERVO 模式下禁用滤波器，该指令在 SERVO 模式下不可设置，退出 SERVO'''
        return self.jakaRobot.servo_move_use_none_filter()
    def servo_move_use_joint_LPF(self,cutoffFreq):
        '''机器人 SERVO 模式下关节空间一阶低通滤波，该指令在 SERVO 模式下不可设置，'''
        return self.jakaRobot.servo_move_use_joint_LPF(cutoffFreq)
    def servo_move_use_joint_NLF(self,max_vr, max_ar, max_jr):
        '''机器人 SERVO 模式下关节空间非线性滤波，该指令在 SERVO 模式下不可设置，退'''
        return self.jakaRobot.servo_move_use_joint_NLF(max_vr, max_ar, max_jr)
    def servo_move_use_carte_NLF(self,max_vp, max_ap, max_jp, max_vr, max_ar, max_jr):
        '''机器人 SERVO 模式下笛卡尔空间非线性滤波，该指令在 SERVO 模式下不可设置，'''
        return self.jakaRobot.servo_move_use_carte_NLF(max_vp, max_ap, max_jp, max_vr, max_ar, max_jr)
    def servo_move_use_joint_MMF(self,max_buf, kp, kv, ka):
        '''机器人 SERVO 模式下关节空间多阶均值滤波，该指令在 SERVO 模式下不可设置，'''
        return self.jakaRobot.servo_move_use_joint_MMF(max_buf, kp, kv, ka)
    def servo_speed_foresight (self,max_buf, kp):
        '''SERVO 模式下速度前瞻参数设置'''
        return self.jakaRobot.servo_speed_foresight (max_buf, kp)
    def set_torsensor_brand(self,sensor_brand):
        '''设置传感器品牌，输入数字代表对应的传感器品牌，可选值为 1，2，3 分别代表不同'''
        return self.jakaRobot.set_torsensor_brand(sensor_brand)
    def get_torsensor_brand(self,):
        '''获取当前所使用的传感器品牌，输出的数字代表不同的传感器品牌。'''
        return self.jakaRobot.get_torsensor_brand()
    def set_torque_sensor_mode(self,sensor_mode):
        '''开启或关闭当前所使用的力矩传感器。'''
        return self.jakaRobot.set_torque_sensor_mode(sensor_mode)
    def set_admit_ctrl_config(self,axis, opt, ftUser, ftConstant, ftNormalTrack, ftReboundFK):
        '''设置机器人柔顺控制时，关节坐标轴编号，柔顺方向，阻尼力，回弹力，恒力，法向'''
        return self.jakaRobot.set_admit_ctrl_config(axis, opt, ftUser, ftConstant, ftNormalTrack, ftReboundFK)
    def start_torq_sensor_payload_identify(self,joint_pos):
        '''开始辨识工具末端负载，输入为一个元组含 6 个元素，分别对应结束位置 6 个关节角。'''
        return self.jakaRobot.start_torq_sensor_payload_identify(joint_pos)
    def get_torq_sensor_identify_status(self,):
        '''获取末端负载辨识状态'''
        return self.jakaRobot.get_torq_sensor_identify_status()
    def get_torq_sensor_payload_identify_result(self,):
        '''获取末端负载辨识结果，输入为负载质量，负载质心位置坐标'''
        return self.jakaRobot.get_torq_sensor_payload_identify_result()
    def set_torq_sensor_tool_payload (self,mass, centroid):
        '''设置传感器末端负载， 输入为负载质量，负载质心位置坐标。'''
        return self.jakaRobot.set_torq_sensor_tool_payload (mass, centroid)
    def get_torq_sensor_tool_payload (self,):
        '''获取传感器末端负载质量，负载质心位置坐标。'''
        return self.jakaRobot.get_torq_sensor_tool_payload ()
    def enable_admittance_ctrl (self,enable_flag):
        '''力控导纳使能控制'''
        return self.jakaRobot.enable_admittance_ctrl (enable_flag)
    def set_compliant_type(self,sensor_compensation, compliance_type):
        '''设置力控类型和传感器初始化状态'''
        return self.jakaRobot.set_compliant_type(sensor_compensation, compliance_type)
    def get_compliant_type(self,):
        '''获取力控类型和传感器初始化状态'''
        return self.jakaRobot.get_compliant_type()
    def get_admit_ctrl_config(self,):
        '''获取力控柔顺控制参数，获取 6 个关节所对应的柔顺方向，阻尼力，回弹力，恒力，'''
        return self.jakaRobot.get_admit_ctrl_config()
    def set_torque_sensor_comm(self,type, ip_addr, port):
        '''设置力矩传感器 IP 地址。'''
        return self.jakaRobot.set_torque_sensor_comm(type, ip_addr, port)
    def get_torque_sensor_comm(self,):
        '''获取力矩传感器 IP 地址。'''
        return self.jakaRobot.get_torque_sensor_comm()
    def disable_force_control (self,):
        '''关闭力矩控制'''
        return self.jakaRobot.disable_force_control ()
    def set_vel_compliant_ctrl (self,level, rate1, rate2, rate3, rate4):
        '''设置速度柔顺控制参数, 速度柔顺控制有 3 个等级，有 4 个比率等级。'''
        return self.jakaRobot.set_vel_compliant_ctrl (level, rate1, rate2, rate3, rate4)
    def get_torque_sensor_soft_limit(self,):
        '''设置柔顺控制力矩条件。'''
        return self.jakaRobot.get_torque_sensor_soft_limit()
    def init_ftp_client(self,):
        '''初始化 ftp 客户端，与控制柜建立连接，可导入导出 program、track'''
        return self.jakaRobot.init_ftp_client()
    def close_ftp_client(self,):
        '''关闭 ftpclient'''
        return self.jakaRobot.close_ftp_client()
    def get_ftp_dir(self,remotedir, type):
        '''查询控制器目录'''
        return self.jakaRobot.get_ftp_dir(remotedir, type)
    def download_file(self,local, remote, opt):
        '''从机器人控制柜的 ftp 下载文件或文件夹到本地，查询轨迹“/track/”,查询脚本程序'''
        return self.jakaRobot.download_file(local, remote, opt)
    def del_ftp_file(self, remote, opt):
        '''从控制器上传指定类型和名称的文件到本地'''
        return self.jakaRobot.del_ftp_file( remote, opt)
    def upload_file(self,local, remote, opt):
        '''重命名控制器指定类型和名称的文件'''
        return self.jakaRobot.upload_file(local, remote, opt)
